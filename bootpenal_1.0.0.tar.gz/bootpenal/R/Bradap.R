#library(ClustOfVar)
#library(msgps)
#library(clValid)
###############################################
###Block random adaptive lasso
Bradap<-function(X,y,nc=5,B=100,q1=4,q2=4,tun=0.5){
  ##step 1 cluster
  pv<-ncol(X)
  n<-length(y)
  ck<-2:nc
  coef=matrix(0,pv,length(tun))
  BIC=NULL
  j=1
for(h in tun){
   if (pv<50){
    clu=hclustvar(X)
    sclu=ClustOfVar::stability(clu,B=50,graph=FALSE) 
    ncluster<-which.max(sclu$meanCR)+1
    part=cutreevar(clu,ncluster)
    K<-ncluster  #number of block  
    clust<-part$cluster 
  }else{
    #cluster evaluation
    TX=t(X)
    rownames(TX)=as.character(c(1:pv))
    if(length(ck)>1){
      clva=clValid(TX, nClust=ck, maxitems=2000, clMethods="kmeans", validation="internal",metric="correlation")
      #optimal number of cluster
      K=as.numeric(as.matrix(optimalScores(clva))[2,3])
    } else
    {
      K=ck  
    }
    clust<-kmeansvar(TX,K,nstart=K,iter.max=50)$cluster
    clust<-as.vector(clust) 
  }
  ##step 2  generating
  coef1=matrix(0,pv,B)
  for (b in 1:B) {
    N=sample(1:n,n,replace=T)
    Xb<-X[N,]
    yb<-y[N]
    K1<-sample(1:K,q1,replace=F)
    K1<-sort(K1)
    P1<-NULL
    for( k in 1:q1) {
      PP=which(clust==K1[k],arr.ind=TRUE)  
      P1=c(P1,PP)    
    }
    P1<-sort(P1)
    rXb<-Xb[,P1] 
    #cv1<-cv.glmnet(rXb,yb)$lambda.min
    alas<-msgps(X=rXb,y=yb,penalty="alasso",lambda=0.01, gamma=3,intercept=F) #adaptive lasso
    #las<-cv.glmnet(rXb,yb,intercept=F)
    coef1[P1,b]=as.matrix(coef(alas)[,1],pv,1) #GCV select tuning 
  }
  IM<-abs(apply(coef1,1,mean)) #important measurement
  IM2<-IM/sum(IM)
  clustf<-as.factor(clust)
  BIM2<-tapply(IM2,clustf,sum)
  
  #step 3
  coef2=matrix(0,pv,B)
  for (b in 1:B) {
    N=sample(1:n,n,replace=T)
    Xb<-X[N,]
    yb<-y[N]
    K2<-sample(1:K,q2,replace=F,prob=BIM2)
    K2<-sort(K2)
    P2<-NULL
    for( k in 1:q2) {
      PP=which(clust==K2[k],arr.ind=TRUE)  
      P2=c(P2,PP)    
    }
    P2<-sort(P2)
    rXb<-Xb[,P2] 
    #las2<-cv.glmnet(rXb,yb,lambda=0,intercept=FALSE)
    alas2<-msgps(X=rXb,y=yb,penalty="alasso", lambda=0.01,gamma=3,intercept=F) #adaptive lasso
    coef2[P2,b]=as.matrix(coef(alas2)[,1],pv,1) #GCV select tuning
      }
  for(z in 1:pv){
    coef2[z,][sum(coef2[z,]==0)>h*B]=0
     }
  coef[,j]<-apply(coef2,1,mean)
  BIC[j]=n*log(mean((y-X%*%coef[,j])^2))+log(n)*(pv-sum(coef[,j]==0))
  j=j+1
  } 
  return(list(coef=coef,coef.min=coef[,which.min(BIC)],nclust=K,clustf=clustf,IM=IM2,BIM=BIM2)) 
} 
