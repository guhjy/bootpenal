#library(MASS)
generate=function(n=100,p=4,r=0.95,pair=FALSE){
  #pair=FALSE generate Auto correlation structure sigma
  #pair=TRUE  generate pair-wise correlation structure sigma
  sigma<-matrix(,p,p)
  if (pair==TRUE){
    for(i in 1:p){
      for(j in i:p){
        sigma[i,j]<-r
        sigma[j,i]<-sigma[i,j]
      }
    }
    diag(sigma)=1
  }
  else{
  for(i in 1:p){
    for(j in i:p){
      sigma[i,j]<-r^abs(i-j)
      sigma[j,i]<-sigma[i,j]
    }
  }
  }
  sample=mvrnorm(n,rep(0,p),sigma)
  return(sample)
}

