FDNR<-function(beta,betatrue)
{
  #return FDR and FNR of results for simulation
  #beta: estimated coefficients
  #betatrue:the true value of coefficients
fn<-0
tp<-0
fp<-0
FNR<-0
FDR<-0
size<-length(beta)
#nvars<-length(which(beta!=0))
for(j in 1:size)
{
if(betatrue[j]!=0&betatrue[j]!=0)
{tp<-tp+1}
if(betatrue[j]!=0&beta[j]==0)
{fn<-fn+1}
if(betatrue[j]==0&beta[j]!=0)
{fp<-fp+1}
}
FNR<-(fn/(tp+fn))
FDR<-(fp/(tp+fp))
#if(fn!=0)
#{FNR<-(fn/(tp+fn))}
#if(fp!=0)
#{FDR<-(fp/(tp+fp))}
#resultmatrix<-c(FNR=FNR,FDR=FDR)
return(list(FNR=FNR,FDR=FDR))
}

