#library(glmnet)
#library(msgps)
####bootstrap penalization for data with large n
split_lasso<-function(X,y,sb=4,tun_s=0.5,method=c("lasso","adap")){   
  #x: covariate matrix
  #y: response
  #sb: the number of sample blocks
  #p: the number of variables
  #tun_s: the tunning parameter for sample(observation) stability selection
  ##method: for lasso or adaptive lasso
  method=match.arg(method)
  #this.call=match.call()
  N<-length(y)
  p<-ncol(X)
  dat<-cbind(y,X)
  sn<-sample(1:N,N,replace=F) ##sample 
  coefs=matrix(0,p,sb)
  coef=matrix(0,p,length(tun_s))
  BIC=NULL
  mse=NULL
  ms0=NULL  #NULL model
  j=1
  for(h in tun_s){
    for (b in 1:sb){
      bn<-na.exclude(sn[((b-1)*ceiling(N/sb)+1):(b*ceiling(N/sb))])
      sdat<-dat[bn,]  
      rdat<-dat[-bn,]
      if (method=="lasso"){
        coefs[,b]<-coef(cv.glmnet(x=sdat[,-1],y=sdat[,1],intercept=F),s="lambda.min")[-1]
        }
      if (method=="adap"){
        coefs[,b]<-coef(msgps(X=sdat[,-1],y=sdat[,1],intercept=F))[,3]   
      }   
      mse[b]<-mean((rdat[,1]-rdat[,-1]%*%coefs[,b])^2)
      ms0[b]<-mean((rdat[,1]-mean(rdat[,1]))^2)
    }
    for(z in 1:p) {
      coefs[z,][sum(coefs[z,]==0)>=h*sb]=0
    }
    pmse<-abs(sqrt(ms0)-sqrt(mse))/sum(abs(sqrt(ms0)-sqrt(mse)))
    coef[,j]<-coefs%*%pmse  #weight avarage
    BIC[j]=N*log(mean(y-X%*%coef[,j])^2)+log(N)*(p-sum(coef[,j]==0))
    j=j+1
  }
  return(list(coef.min=coef[,which.min(BIC)],PMSE=pmse) ) 
}
