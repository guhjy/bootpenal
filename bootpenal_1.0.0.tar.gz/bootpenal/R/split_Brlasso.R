####bootstrap penalization for data with large n and large p
split_Brlasso<-function(X,y,sb=4,nc=5,B=100,q1=3,q2=3,tun_s=0.5,tun=0.5,method=c("Brlasso","Bradap")){   ### for lasso and net
  #x: covariate matrix
  #y: response
  #sb: the number of sample blocks
  #nc: the maximum number of cluster of variables
  #q1,q2: the number of blocks selected in step 2 and 3 respectively.
  #tun_s: the tunning parameter for sample(observation) stability-based selection
  #tun: the tunning parameter for variables stability-based selection
  #method: for block lasso or block adaptive lasso
  method=match.arg(method)
  N<-length(y)
  p<-ncol(X)
  ck=2:nc
  dat<-cbind(y,X)
  sn<-sample(1:N,N,replace=F)  
  coefs=matrix(0,p,sb)
  coef=matrix(0,p,length(tun_s))
  BIC=NULL
  mse=NULL
  ms0=NULL  #NULL model
  j=1
  for(h in tun_s){
    for (b in 1:sb){
      bn<-na.exclude(sn[((b-1)*ceiling(N/sb)+1):(b*ceiling(N/sb))])
      sdat<-dat[bn,]  
      rdat<-dat[-bn,]
      if (method=="Brlasso"){
        res<-Brlasso(X=sdat[,-1],y=sdat[,1],nc=nc,B=B,q1=q1,q2=q2,tun=tun)
        coefs[,b]<-res$coef.min
      }
      if (method=="Bradap")  {
       res<-Bradap(X=sdat[,-1],y=sdat[,1],nc=nc,B=B,q1=q1,q2=q2,tun=tun) 
      coefs[,b]<-res$coef.min
      }    
      mse[b]<-mean((rdat[,1]-rdat[,-1]%*%coefs[,b])^2)
      ms0[b]<-mean((rdat[,1]-mean(rdat[,1]))^2)
    }
    for(z in 1:p) {
      coefs[z,][sum(coefs[z, ]==0)>=h*sb]=0
    }
    pmse<-abs(sqrt(ms0)-sqrt(mse))/sum(abs(sqrt(ms0)-sqrt(mse)))
    coef[,j]<-coefs%*%pmse  #weight avarage
    BIC[j]=N*log(mean(y-X%*%coef[,j])^2)+log(N)*(p-sum(coef[,j]==0))
    j=j+1
  }
  return(list(coef.min=coef[,which.min(BIC)],PMSE=pmse))  
} 
